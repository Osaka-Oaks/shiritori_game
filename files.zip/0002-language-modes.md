# ADR 0002: One engine, two language modes

## Status
Accepted

## Context
The game must serve four audiences across two languages:

- English speakers playing casual English shiritori,
- native Japanese kids (simple hiragana),
- native Japanese adults (full vocabulary),
- English speakers learning Japanese (kana + romaji + meaning, difficulty tiers).

English and Japanese differ in match unit (letter vs kana), banned ending
(none vs ん), word type (any vs nouns-only), and normalization (case vs
kana-folding). A naive approach would fork into two codebases.

## Decision
Build a **single validation engine parameterized by a per-language config
object** (see `docs/design.md`). Language differences are data, not branches:

- match unit, banned ending, nouns-only, and normalization all come from config;
- house rules (`lenientDakuten`, banned ending) are flags, not new code paths;
- the learner layer (romaji input, tiered vocabulary, tri-format display) sits
  on top of the Japanese config and does not alter the engine.

## Consequences
- (+) Repeat-tracking, chain logic, UI, and the test harness are shared.
- (+) New house rules or a new mode become configuration, not a rewrite.
- (+) One code path to test — most test effort concentrates on **kana
      normalization**, the riskiest part (see `docs/tests/test-cases.md`).
- (−) The config abstraction must be right up front; a sloppy config shape would
      leak language-specific logic back into the engine.
- (−) Kana normalization (katakana→hiragana, `ー`→vowel, small-kana folding,
      dakuten leniency) is genuinely fiddly and needs thorough tests.

## Revisit if
A future language (e.g. Korean 끝말잇기) needs matching behavior the current
config shape can't express.
