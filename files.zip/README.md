# Shiritori (しりとり)

A word-chain game for **two languages and four kinds of player**:

- English speakers playing a casual English chain
- English speakers **learning Japanese** (kana + romaji + English meaning shown)
- Native Japanese **kids** (simple hiragana vocabulary)
- Native Japanese **adults** (full vocabulary)

Each word must begin with the last letter/kana of the previous word. Don't repeat a
word, don't break the chain, and — in Japanese — don't play a word ending in ん.

---

## How to play

1. The first player enters any valid word.
   - English: `apple`
   - Japanese: `りんご` (or type romaji `ringo` in learner mode)
2. The next word must **start with the previous word's last letter/kana**.
   - English: `apple` → **e** → `elephant`
   - Japanese: `りんご` → **ご** → `ゴリラ`
3. You **lose** if you:
   - repeat a word already used,
   - break the chain (wrong starting letter/kana), or
   - **(Japanese only)** play a word ending in ん / "n".

Difficulty tiers control how big the allowed vocabulary is — see
[`docs/rules.md`](docs/rules.md).

---

## Run it

Requires the [Flutter SDK](https://docs.flutter.dev/get-started/install)
(includes Dart). Check your setup first, then run:

```bash
flutter doctor          # verify SDK + a target device
flutter pub get         # install dependencies
flutter run             # run on the connected device / emulator
```

Pick a target explicitly if needed:

```bash
flutter run -d chrome   # web
flutter run -d macos    # desktop
flutter devices         # list what's available
```

Run the tests:

```bash
flutter test
```

---

## Project layout

```
shiritori/
├── README.md              ← you are here
├── CHANGELOG.md
├── pubspec.yaml           ← Flutter deps + asset registration
├── lib/
│   ├── main.dart          ← app entry + UI (your code)
│   ├── engine.dart        ← validateWord() + game state
│   ├── kana.dart          ← kana normalization
│   └── romaji.dart        ← romaji → kana (learner input)
├── assets/data/
│   ├── en.json            ← English word list
│   └── ja.json            ← Japanese list (kana + romaji + gloss + tier)
├── test/
│   └── engine_test.dart   ← from docs/tests/test-cases.md
└── docs/
    ├── design.md          ← architecture + core logic
    ├── rules.md           ← THE rule spec (both languages)
    ├── adr/               ← recorded decisions
    │   ├── 0001-word-validation.md
    │   ├── 0002-language-modes.md
    │   └── 0003-flutter-dart.md
    └── tests/
        └── test-cases.md
```

---

## Tech

- **Framework / language:** Flutter + Dart
- **Targets:** Android, iOS, web, desktop (one codebase)
- **Word data:** bundled JSON assets, English + Japanese (romaji + glosses)

See [`docs/design.md`](docs/design.md) for how it's built and
[`docs/rules.md`](docs/rules.md) for exactly how the game behaves.
