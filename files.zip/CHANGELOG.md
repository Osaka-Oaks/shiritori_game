# Changelog

All notable changes to this project are recorded here. Newest on top.
Format follows [Keep a Changelog](https://keepachangelog.com/); versions follow
[Semantic Versioning](https://semver.org/).

## [Unreleased]
### Planned
- Core chain validation engine (English + Japanese config).
- Kana normalization: katakana→hiragana, `ー`→vowel, small-kana folding.
- Romaji input for learner tiers.
- Word lists: `data/en.json`, `data/ja.json` with romaji, glosses, tiers.

## [0.1.0] - 2026-07-10
### Added
- Project documentation set: README, design, rule spec, ADRs 0001–0002,
  test cases.
