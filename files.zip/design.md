# Shiritori — Design

How the game is built. For *what the game does*, see [`rules.md`](rules.md).

## Goals

- One validation engine that serves English + Japanese by configuration.
- Learner support (romaji input, kana/romaji/meaning display, difficulty tiers).
- One Flutter codebase across Android, iOS, web, and desktop.

## Architecture

Three layers, kept separate so rules can change without touching the UI. The
engine is **pure Dart with no Flutter imports** — that keeps it fast to unit-test
(`flutter test`) and reusable on any target.

```
┌─────────────────────────────────────────────┐
│  UI (lib/main.dart, Flutter widgets)         │  input field, chain list, mode switch
├─────────────────────────────────────────────┤
│  Engine (lib/engine.dart)  — pure Dart       │  validateWord(), GameState
│    ├─ LanguageConfig per mode (rules.md)     │
│    ├─ lib/kana.dart   normalization          │
│    └─ lib/romaji.dart romaji → kana          │
├─────────────────────────────────────────────┤
│  Data (assets/data/en.json, ja.json)         │  word lists + romaji + glosses + tier
└─────────────────────────────────────────────┘
```

Register the data as assets in `pubspec.yaml`:

```yaml
flutter:
  assets:
    - assets/data/en.json
    - assets/data/ja.json
```

Load them at startup with `rootBundle.loadString('assets/data/ja.json')` and
decode with `dart:convert`'s `jsonDecode`.

## Language config

The engine is parameterized by one `LanguageConfig` per mode (mirrors `rules.md`):

```dart
enum MatchUnit { letter, kana }

class LanguageConfig {
  final MatchUnit matchUnit;
  final String? bannedEnding;   // null in English, 'ん' in Japanese
  final bool nounsOnly;
  final bool lenientDakuten;
  final String Function(String) normalize;

  const LanguageConfig({
    required this.matchUnit,
    required this.bannedEnding,
    required this.nounsOnly,
    required this.lenientDakuten,
    required this.normalize,
  });
}

final english = LanguageConfig(
  matchUnit: MatchUnit.letter,
  bannedEnding: null,
  nounsOnly: false,
  lenientDakuten: false,
  normalize: (w) => w.trim().toLowerCase(),
);

final japanese = LanguageConfig(
  matchUnit: MatchUnit.kana,
  bannedEnding: 'ん',
  nounsOnly: true,
  lenientDakuten: true,
  normalize: normalizeKana,     // from lib/kana.dart
);
```

## Core function

```dart
class ValidationResult {
  final bool valid;
  final bool losing;
  final String reason;
  const ValidationResult(this.valid, this.losing, this.reason);
}

ValidationResult validateWord(
  String word,
  String? previousWord,
  Set<String> usedWords,
  LanguageConfig config,
  bool Function(String) inDictionaryTier,
) {
  final w = config.normalize(word);

  if (w.isEmpty) return const ValidationResult(false, false, 'empty input');
  if (!inDictionaryTier(w)) {
    return const ValidationResult(false, false, 'not a valid word for this tier');
  }
  if (usedWords.contains(w)) {
    return const ValidationResult(false, false, 'word already used');
  }
  if (previousWord != null &&
      firstUnit(w, config) != lastUnit(previousWord, config)) {
    return const ValidationResult(false, false, 'wrong starting letter/kana');
  }
  final banned = config.bannedEnding;
  if (banned != null && lastUnit(w, config) == banned) {
    return const ValidationResult(true, true, 'ends in banned kana');
  }
  return const ValidationResult(true, false, 'ok');
}
```

`firstUnit` / `lastUnit` live in `lib/kana.dart`: a plain first/last character in
English mode, and the normalized last-matching kana (handling `ー` and small kana)
in Japanese mode.

## Data format

`data/ja.json` entries carry everything the learner layer needs:

```json
{ "kana": "ゴリラ", "romaji": "gorira", "gloss": "gorilla", "tier": 2, "noun": true }
```

`data/en.json` is simpler:

```json
{ "word": "elephant", "noun": true }
```

## Romaji input (learner tiers only)

- Input string is run through a romaji→kana converter before validation.
- Native (kana-only) mode skips this step entirely.
- Keep the converter as a separate file (`lib/romaji.dart`) so it can be tested
  and swapped without touching the engine.

## Edge cases to design against (see tests/test-cases.md)

- Empty / whitespace-only input
- Word not in dictionary, or in dictionary but above the active tier
- English case differences (`Apple` vs `apple`)
- Japanese katakana vs hiragana (`カレー` vs `かれー`)
- Long vowel `ー` ending (`カレー` → ends in `え`)
- Small kana ending (`きしゃ` → matches `や`)
- Voiced kana under `lenientDakuten` (`が` vs `か`)
- Losing move: word ending in `ん`

## Out of scope (v1)

Online multiplayer, accounts, a server backend, timed rounds. If any of these
land later, add an ADR and revisit this document.
