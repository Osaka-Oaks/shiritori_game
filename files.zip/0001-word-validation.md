# ADR 0001: Word validation source

## Status
Accepted

## Context
The game must reject non-words in both English and Japanese. Options considered:

1. **Hardcoded array in code** — fast to start, but mixes data with logic and
   is painful to grow.
2. **Bundled local word-list files** (`data/en.json`, `data/ja.json`).
3. **Online dictionary API** — largest vocabulary, but needs network, adds
   latency and rate limits, and can go down mid-game.

The Japanese list is not just words — it also needs romaji and English glosses
for the learner layer, plus a difficulty tier per entry.

## Decision
Use **bundled local word-list files**, one per language, shipped with the app.

- `data/en.json` — `{ word, noun }`
- `data/ja.json` — `{ kana, romaji, gloss, tier, noun }`

## Consequences
- (+) Works fully offline; no rate limits; instant validation.
- (+) Tiering and glosses live right next to the words that need them.
- (+) Deterministic — the same word list produces the same test results.
- (−) Vocabulary is fixed at ship time; growing it means editing the data files.
- (−) Someone has to curate the Japanese list (romaji + glosses + tiers). This is
      the single biggest content task in the project.

## Revisit if
We want a much larger adult vocabulary than we can hand-curate — at which point a
dictionary API behind the local list (local first, API fallback) becomes worth it.
