# Shiritori — Test Cases

Plain-language scenarios the engine must pass. Each maps directly to a rule in
[`../rules.md`](../rules.md). Turn these into automated tests as you build.

## English mode

| #  | Prev word     | Input   | Expected                          |
|----|---------------|---------|-----------------------------------|
| E1 | (start)       | apple   | Valid                             |
| E2 | apple         | egg     | Valid (a…**e** → **e**…)          |
| E3 | apple         | dog     | Invalid — wrong start letter      |
| E4 | apple → egg   | apple   | Invalid — repeat                  |
| E5 | apple         | Egg     | Valid — case normalized           |
| E6 | apple         | (blank) | Invalid — empty input             |
| E7 | apple         | asdfgh  | Invalid — not in dictionary       |

## Japanese mode (native, kana input)

| #   | Prev word        | Input      | Expected                                   |
|-----|------------------|------------|--------------------------------------------|
| J1  | りんご (ringo)   | ゴリラ     | Valid — ご → ゴ (katakana normalized)      |
| J2  | さくら (sakura)  | らくだ     | Valid — ら → ら                            |
| J3  | ぞう (zou)       | うま       | Valid — う → う                            |
| J4  | みかん (mikan)   | —          | **Loss** — word ends in ん                 |
| J5  | カレー (karee)   | えんぴつ   | Valid — ー counts as え                    |
| J6  | きしゃ (kisha)   | やま       | Valid — small ゃ matches full や           |
| J7  | りんご → ゴリラ  | りんご     | Invalid — repeat                           |
| J8  | さかな (sakana)  | いぬ       | Invalid — wrong start kana (な ≠ い)       |

## Japanese house rules

| #   | Prev word       | Input   | Flag                    | Expected                          |
|-----|-----------------|---------|-------------------------|-----------------------------------|
| H1  | りんご          | かさ    | `lenientDakuten = true` | Valid — が-base か accepted        |
| H2  | りんご          | かさ    | `lenientDakuten = false`| Invalid — strict dakuten          |

## Learner layer (romaji input)

| #   | Prev word     | Input (romaji) | Tier | Expected                                  |
|-----|---------------|----------------|------|-------------------------------------------|
| L1  | りんご        | gorira         | 2    | Valid — romaji → ゴリラ, ご → ゴ           |
| L2  | りんご        | gorira         | 1    | Invalid — katakana word above tier 1      |
| L3  | (start)       | ringo          | 1    | Valid — common hiragana noun              |
| L4  | さくら        | rakuda         | 1    | Valid                                     |

## Notes

- J5 and J6 are the highest-risk cases — most bugs will hide in `ー` handling and
  small-kana folding. Add extra variants there as you find edge cases.
- Every "Loss" result should still register the word (so the UI can show *why*
  the player lost), but end the round.
