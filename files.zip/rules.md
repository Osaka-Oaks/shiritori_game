# Shiritori — Rule Specification

This is the **source of truth** for how the game behaves. Code and tests must
match this document. Written in English; describes both language modes.

The game runs in two modes. Both share three rules:

1. **Chain-matching** — next word starts where the previous word ended.
2. **No repeats** — a word may be used only once per game (tracked in a set).
3. **Banned ending** — a configurable ending that causes an immediate loss.

Everything else is per-language configuration, so there is **one engine**, not two.

---

## 1. English mode

| Property           | Value                                             |
|--------------------|---------------------------------------------------|
| Match unit         | last **letter** → first letter                    |
| Banned ending      | none by default (`bannedEnding = null`)           |
| Word type          | any word by default; `nounsOnly` flag optional    |
| Normalization      | lowercase, trim surrounding whitespace            |

Example chain: `apple` → `elephant` → `tiger` → `rabbit` …

---

## 2. Japanese mode (しりとり)

| Property           | Value                                             |
|--------------------|---------------------------------------------------|
| Match unit         | last **kana** → first kana                        |
| Banned ending      | ん / "n" → **immediate loss**                     |
| Word type          | nouns only (traditional): `nounsOnly = true`      |
| Normalization      | applied **before** matching (see below)           |

### Normalization (applied before matching)

Order matters. Apply top to bottom:

1. **Katakana → hiragana** — so `カレー` and `かれー` are treated the same.
2. **Long vowel `ー`** → the vowel it represents.
   `カレー` is treated as ending in **え** (ka-re-e).
3. **Small kana `ゃ ゅ ょ っ`** → their full-size form for matching.
   `きしゃ` (kisha) is treated as ending in **や**.

### House-rule flags (defaults are kid-friendly)

| Flag             | Default | Meaning                                              |
|------------------|---------|------------------------------------------------------|
| `bannedEnding`   | `ん`    | Playing a word ending here = loss                    |
| `nounsOnly`      | `true`  | Only nouns allowed (traditional)                     |
| `lenientDakuten` | `true`  | `が` may follow / be followed by `か` (voiced = base) |

`lenientDakuten` exists because strict dakuten matching is hard for kids. Adults
who want the strict version set it to `false`.

---

## 3. Learner layer (English speakers, Japanese mode)

When a Japanese-learning profile is active, each word is **displayed** three ways:

```
ゴリラ  /  gorira  /  "gorilla"
```

- **Input** accepts romaji (`gorira`) and converts to kana, OR direct kana input.
- **Native mode** accepts kana only (romaji conversion off).

### Difficulty tiers (gate the allowed word list)

| Tier | Audience              | Allowed vocabulary                     |
|------|-----------------------|----------------------------------------|
| 1    | kids / beginners      | common hiragana nouns only             |
| 2    | intermediate          | + katakana loanwords                   |
| 3    | adults / advanced     | full dictionary                        |

A word is valid only if it is (a) in the dictionary and (b) within the active
tier's list.

---

## 4. Decision flow (both modes)

For an input word `W`, previous word `P`, and used-word set `U`:

1. Normalize `W` per the active mode.
2. If `W` is empty → **reject** (invalid input).
3. If `W` not in dictionary / not in active tier → **reject**.
4. If `W ∈ U` → **reject** (repeat = loss).
5. If `P` exists and `firstUnit(W) ≠ lastUnit(P)` → **reject** (broken chain).
6. If `lastUnit(W) == bannedEnding` → **accept but mark as losing move**.
7. Otherwise → **accept**, add `W` to `U`, set `P = W`.

`firstUnit` / `lastUnit` mean *letter* in English mode and *normalized kana* in
Japanese mode.
